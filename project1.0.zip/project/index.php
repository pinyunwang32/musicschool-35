<?php 
$passed_title = 'Signin';

include('./include_files/HTML_MENU.inc'); // INCLUDING HTML MENU ?>
    <!DOCTYPE HTML>
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Simply</title>
        <!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    <div id="hero-image">
        <div class="wrapper">
            <h2><strong>A Minimal, clean</strong><br/>
                layout for web design.</h2>
            <a href="#" class="button-1">Get Started</a>
        </div>
    </div>

    <body>

    </body>
    </html>




<?php include('./include_files/footer.inc');  // HTML FOOTER INCLUDE FILE?>